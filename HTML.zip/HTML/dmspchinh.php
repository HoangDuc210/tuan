<html>

<head>
	<title></title>
	<meta name="viewport" content="width=device-width" initial-scale=1.0>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
	<link rel="stylesheet" href="theme/frontend/css/font-awesome.css">
	<link rel="stylesheet" href="theme/frontend/css/jquery.fancybox.css">
	<link rel="stylesheet" href="theme/frontend/css/toastr.min.css">
	<link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css"/>
	<link rel="stylesheet" href="theme/frontend/css/reset.css">
	<link rel="stylesheet" href="theme/frontend/css/style.css">
	<link rel="stylesheet" href="theme/frontend/css/mobile.css">

</head>

<body> 

	<div class="product-main">
		<h1 class="title_b text-center mt-5 mb-5">Danh mục sản phẩm</h1>

		<?php for ($i = 1; $i <= 2; $i++) { ?>
			<div class="container mt-3">
				<div class="box-cate-pro">
					<a href="" class="smooth box-img" title="">
						<img src="theme/frontend/images/boncau.jpg">
					</a>
					<h2 class="title">
						<a href="" class="smooth" title="">Bồn cầu</a>
					</h2>
				</div>
				<div class="row">
					<?php for ($a = 1; $a <= 3; $a++) { ?>
						<div class="col-4">
							<h3 class="title_c text-center mt-4 mb-3">
								<a href="" title="" class="smooth">
									Bồn cầu ngồi
								</a>
							</h3>
						</div>
					<?php }?>
				</div>
			</div>	
		<?php }?>

		<div class="container mt-5 mb-5">
			<div class="row">
				<?php for ($i = 1; $i <= 2; $i++) { ?>
					<div class="col-6">
						<h3 class="title_c title_no_image">
							<a href="" title="" class="smooth d-block">
								Bồn cầu ngồi
							</a>
						</h3>
					</div>
				<?php }?>
			</div>
		</div>	

		<div class="truck-advise mt-5 mb-5">
			<div class="container ">
				<div class="row">
					<?php for ($i = 1; $i <= 3; $i++) { ?>
						<div class="col-4">
							<div class="box-img">
								<img src="theme/frontend/images/baomat.png">
							</div>
							<p class="title text-center mt-2">100% hàng đặt tiêu chuẩn chất lượng cao</p>
						</div>
					<?php }?>
				</div>
			</div>	
		</div>

		<div class="box-products-new mb-5">
			<div class="container">
				<div class="box-title">
					<h2 class="title">Sản phẩm mới</h2>
					<a href="" title="" class="smooth views-more">Xem thêm</a>
				</div>
				<div class="swiper product-slide-new mt-5">
					<div class="swiper-wrapper">
						<?php for ($i = 1; $i <= 6; $i++) { ?>
							<div class="swiper-slide">
								<div class="box-card-pro">
									<a href="" title="" class="smooth box-img">
										<img src="theme/frontend/images/chauruamat.png" >
									</a>
									<h3 class="pro-name text-center mt-4">Chậu rửa đặt bàn TK58</h3>
								</div>
							</div>
						<?php }?>
					</div>
					<div class="swiper-button-next"></div>
					<div class="swiper-button-prev"></div>
					<!-- 					<div class="swiper-pagination"></div> -->
				</div>
			</div>
		</div>
		

		
	</div>
	


</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
<script type="text/javascript" src="theme/frontend/js/jquery-3.4.1.min.js" defer=""></script>
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
<script src="theme/frontend/js/test.js" defer></script>


</html>

