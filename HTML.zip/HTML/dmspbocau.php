<html>

<head>
	<title></title>
	<meta name="viewport" content="width=device-width" initial-scale=1.0>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
	<link rel="stylesheet" href="theme/frontend/css/font-awesome.css">
	<link rel="stylesheet" href="theme/frontend/css/jquery.fancybox.css">
	<link rel="stylesheet" href="theme/frontend/css/toastr.min.css">
	<link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css"/>
	<link rel="stylesheet" href="theme/frontend/css/reset.css">
	<link rel="stylesheet" href="theme/frontend/css/style.css">
	<link rel="stylesheet" href="theme/frontend/css/mobile.css">

</head>

<body> 

	<div class="product-main">
		<div class="container">
			<div class="row">
				<div class="col-3">
					<div class="categories">
						<p class="title">Danh mục sản phẩm</p>
						<ul>
							<?php for ($i = 1; $i <= 3; $i++) { ?>
								<li>
									<a href="" title="" class="smooth">Bồn cầu <?php echo $i;?></a>
									<ul>
										<?php for ($a = 1; $a <= 3; $a++) { ?>
											<li>
												<a href="" title="" class="smooth"> Bồn cầu <?php echo $a;?></a>
											</li>
										<?php }?>
									</ul>
								</li>
							<?php }?>
						</ul>
					</div>
				</div>
				<div class="col-9">
					<div class="box-cate-pro">
						<a href="" class="smooth box-img" title="">
							<img src="theme/frontend/images/boncau.jpg">
						</a>
						<h2 class="title">
							<a href="" class="smooth" title="">Bồn cầu</a>
						</h2>
					</div>
					
					<div class="row mt-4">

						<?php for ($i = 1; $i <= 5; $i++) { ?>
							<div class="col-3 mb-4">
								<div class="box-img-pro">
									<img src="theme/frontend/images/boncau.jpg">
									<a href="" title="" class="smooth title"> Bồn cầu</a>
								</div>
							</div>
						<?php }?>
					</div>
					
					<div class="list-pro">

						<form class="form-search-pro mb-3">
							<div class="box-title">
								<p class="title">Sắp xếp the</p>
								<p class="title">Sản phẩm mới nhất</p>
							</div>
							<div class="form-group">
								<input type="" name="" class="form-control" placeholder="Tìm kiếm theo">
								<button type="submit" class="btn"><i class="fa fa-search"></i></button>
							</div>
						</form>

						<div class="row row-fix">

							<?php for ($i = 1; $i <= 9; $i++) { ?>
								<div class="col-3 col-fix">
									<div class="box-card-pro">
										<a href="" title="" class="smooth box-img">
											<img src="theme/frontend/images/chauruamat.png" >
										</a>
										<h3 class="pro-name text-center mt-4">Chậu rửa đặt bàn TK58</h3>

										<a href="" class="smooth contact d-block text-center">Liên hệ</a>

										<div class="rate-status">
											<div class="rate">(116)</div>
											<p class="status">Còn hàng</p>
										</div>
									</div>
								</div>
							<?php }?>

						</div>

						<a href="" class="sooth views-more mt-4 mb-4 d-block text-center" >Xem thêm</a>
					</div>

					<div class="relate-news"></div>
					<div class="s-content mt-5">
						<p>
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
						consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
						cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
						proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
						</p>
						<p>
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
						consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
						cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
						proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
						</p>
						<p>
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
						consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
						cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
						proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
						</p>
						<p>
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
						consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
						cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
						proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
						</p>
						<p>
							<img src="theme/frontend/images/boncau.jpg">
						</p>
						<p>
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
						consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
						cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
						proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
						</p>
						<p>
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
						consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
						cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
						proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
						</p>
						<p>
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
						consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
						cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
						proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
						</p>
						<p>
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
						consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
						cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
						proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
						</p>
					</div>
				</div>				
			</div>
		</div>

	</div>
	


</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
<script type="text/javascript" src="theme/frontend/js/jquery-3.4.1.min.js" defer=""></script>
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
<script src="theme/frontend/js/test.js" defer></script>


</html>

