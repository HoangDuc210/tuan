var SLIDE = (function () {
    var productNewSlide = function(){
        if ($('.swiper-slide').length > 0) {
            var swiper = new Swiper(".product-slide-new", {
                slidesPerView: 4,
                spaceBetween: 30,
                // slidesPerGroup: 3,
                loop: true,
                loopFillGroupWithBlank: true,
                pagination: {
                  el: ".swiper-pagination",
                  clickable: true,
              },
              navigation: {
                  nextEl: ".swiper-button-next",
                  prevEl: ".swiper-button-prev",
              },
          });
        }
    }

    return {
        _: function () {
            productNewSlide();
        }
    }
})();
var WEBS = (function () {
    var categories = function(){
        $('.categories ul').find('li').each(function(index, el) {
            if ($(this).find('ul li').length > 0) {
                $(this).prepend('<i class="plus"></i>');
            }
        });
        $('.categories ul').find('li i').click(function(event) {
            var ul=$(this).nextAll("ul");
            if(ul.is(":hidden")){
                $(this).addClass('active');
                ul.slideDown(200);
            }
            else{
                $(this).removeClass('active');
                ul.slideUp();
            }
        });
    }

    var pro_detail = function () {
        if ($('.detail_pro_2').length>0) {
            var swiper = new Swiper(".detail_pro_2", {
                loop: true,
                spaceBetween: 10,
                slidesPerView: 4,
                freeMode: true,
                watchSlidesProgress: true,
            });
        }
        if ($('.detail_pro_1').length>0) {
            var swiper2 = new Swiper(".detail_pro_1", {
                loop: true,
                spaceBetween: 10,
                navigation: {
                  nextEl: ".swiper-button-next",
                  prevEl: ".swiper-button-prev",
              },
              thumbs: {
                  swiper: swiper,
              },
          });
        }
        
    }

    return {
        _: function () {
            categories();
            pro_detail();
        }
    }
})();


jQuery(document).ready(function ($) {
    SLIDE._();
    WEBS._();
});