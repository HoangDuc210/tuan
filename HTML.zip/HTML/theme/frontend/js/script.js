var PROGRAM = (function() {
    var win = $(window);
    var html = $('html');
    var mainBody = $('.main-body');
    var nav = $('.nav--block');
    var menu = nav.children('ul');
    var btnSearch = $('.show-search');
    var frmSearch = $('header .elm-form--search');
    var blur = $('.blur');

    var showSearch = function() {
            btnSearch.click(function(event) {
                event.stopPropagation();
                if (!frmSearch.hasClass('active')) {
                    frmSearch.addClass('active');
                } else {
                    frmSearch.removeClass('active');
                }
            })
        }
        /* Thay đổi số lượng theo nút nhấn input number */
    var frm_InputClick = function() {
        var amountPro = $('.amount');
        amountPro.children('input').val(1);
        amountPro.children('.minus').click(function(event) {
            valueIndex = amountPro.children('input').val();
            valueIndex = valueIndex - 1;
            if (valueIndex == 0) {
                amountPro.children('input').val(1);
            } else {
                amountPro.children('input').val(valueIndex);
            }
        });
        amountPro.children('.sum').click(function(event) {
            valueIndex = amountPro.children('input').val();
            valueIndex = parseInt(valueIndex) + 1;
            amountPro.children('input').val(valueIndex);
        });
    }

    /* Thay đổi tổng tiền với thành tiền khi change số lượng */
    var frm_ChangeCostNumber = function() {
        $('.table-cart input[type="number"]').on('change', function(event) {
            event.preventDefault();
            var costItem = $(this).parent().parent().find('.cost-pro');
            var costItemFinal = $(this).parent().parent().find('.cost-final');
            var sum = $(this).val() * costItem.attr('data-value');
            costItemFinal.text(sum + 'đ');
            costItemFinal.attr('data-cost', sum);
            var arrSum = $('.cost-final');
            var sumCost = 0;
            arrSum.each(function(index, el) {
                sumCost += parseInt($(this).attr('data-cost'));
            });
            $('.sumcost').text(sumCost + 'đ');
        });
    }

    /* Lọc giá trị input number */
    var frm_inputFilterNumber = function() {
        $('input[type="number"').keydown(function(event) {
            if (!(!event.shiftKey &&
                    !(event.keyCode < 48 || event.keyCode > 57) ||
                    !(event.keyCode < 96 || event.keyCode > 105) ||
                    event.keyCode == 46 ||
                    event.keyCode == 8 ||
                    event.keyCode == 190 ||
                    event.keyCode == 9 ||
                    (event.keyCode >= 35 && event.keyCode <= 39)
                )) {
                event.preventDefault();
            }
        });
    }

    /* Hàm chạy chữ khi load trang */
    var NumberUp = function() {
        if ($('.number_up').length > 0) {
            var capacityStatus = 0;
            win.scroll(function() {
                if (capacityStatus == 0 && win.scrollTop() > ($(".to_call_numberup ").offset().top)) {
                    if ($('.count').length > 0) {
                        $('.count').each(function() {
                            $(this).prop('Counter', 0).animate({
                                Counter: $(this).text().replace(/\D/g, '').replace(/ /g, '')
                            }, {
                                duration: 3000,
                                easing: 'swing',
                                step: function(now) {
                                    $(this).text(Math.ceil(now));
                                }
                            });
                        });
                    }
                    capacityStatus = 1;
                }
            });
        }
    }

    /* Hàm nhấn nút play trong video */
    var playVideo = function() {
        var play = $('.play-btn');
        var video = $('#video_banner');
        var videoReload = $('.text_slide');
        play.click(function(event) {
            event.preventDefault();
            video[0].play();
            $(this).hide();
        });
        videoReload.click(function(event) {
            event.stopPropagation();
            if (video[0].play()) {
                video[0].pause();
                $('.play-btn').show();
            }
        });
    }

    /* Hàm load menu - cần có CSS */
    var loadMenuMobile = function() {
        var showMenu = $('.show-menu');
        var closeMenu = $('.bt-close')
        if (win.width() < 991) {
            menu.find('li').each(function(index, el) {
                if ($(this).find('ul li').length > 0) {
                    $(this).prepend('<i></i>');
                }
            });
            menu.find('i').click(function(event) {
                var offParent = $(this).offsetParent();
                var index = $(this).offsetParent().children('ul');
                var cursor = $(this);
                if (index.is(':hidden')) {
                    offParent.parent().find('ul').not(index).slideUp(250);
                    offParent.parent().find('ul').not(index).siblings('i').removeClass('active');
                    cursor.addClass('active');
                    index.slideToggle(250);
                    event.stopPropagation();
                } else {
                    cursor.removeClass('active');
                    index.slideUp(250);
                }
                event.stopPropagation();
            });
        }
        showMenu.click(function(event) {
            if (!nav.hasClass('active')) {
                blur.addClass('active');
                nav.addClass('active');
                frmSearch.removeClass('active');
            } else {
                nav.removeClass('active');
                blur.removeClass('active');
            }
            event.stopPropagation();
        });
        closeMenu.click(function(event) {
            nav.removeClass('active');
            mainBody.removeClass('active-menu');
            event.stopPropagation();
        });

    }

    /* Hàm chống COPY F12 */
    var stopCopyCraw = function() {
        var ctrlDown = false,
            ctrlKey = 17,
            cmdKey = 91,
            vKey = 86,
            cKey = 67;
        $('body').bind('cut copy paste', function(e) {
            e.preventDefault();
            return false;
        });

        document.onkeydown = function(e) {
            if (e.ctrlKey &&
                (e.keyCode === 67 ||
                    e.keyCode === 86 ||
                    e.keyCode === 85 ||
                    e.keyCode === 117)) {
                return false;
            } else {
                return true;
            }
        };
        $(document).keypress("u", function(e) {
            if (e.ctrlKey) {
                return false;
            } else {
                return true;
            }
        });
        $(document).keydown(function(event) {
            if (event.keyCode == 123) {
                return false;
            } else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) {
                return false;
            }
        });
        $(document).on("contextmenu", function(e) {
            e.preventDefault();
        });
    }

    /* Hàm winClick */
    var loadWinClick = function() {
        win.click(function(e) {
            if (win.width() < 991 && nav.has(e.target).length == 0 && !nav.is(e.target)) {
                nav.removeClass('active');
                blur.removeClass('active');
            }
            if (win.width() < 991 && frmSearch.has(e.target).length == 0 && !frmSearch.is(e.target)) {
                frmSearch.removeClass('active');
            }
        });
    }

    /* Hàm loadEffectWow JS */
    var loadEffectWow = function() {
        wow = new WOW();
        wow.init();
    }

    /* Hàm setting Toastr */
    var loadToastr = function() {
        toastr.options = {
            "closeButton": false,
            "debug": false,
            "newestOnTop": false,
            "progressBar": false,
            "positionClass": "toast-bottom-left",
            "preventDuplicates": false,
            "onclick": null,
            "showDuration": "300",
            "hideDuration": "1000",
            "timeOut": "5000",
            "extendedTimeOut": "1000",
            "showEasing": "swing",
            "hideEasing": "linear",
            "showMethod": "fadeIn",
            "hideMethod": "fadeOut"
        }
        if (typeNotify != '' && messageNotify != '') {
            toastr.clear();
            toastr[typeNotify](messageNotify);
        }
    }


    /* Load plugins FB,GG */
    var loadSocial = function() {
        $(window).bind("load", function() {
            setTimeout(function() {
                $('body').append('<div id="fb-root"></div>');
                $.ajax({
                    global: false,
                    url: "theme/frontend/js/social.js",
                    dataType: "script"
                });
                $.ajax({
                    global: false,
                    url: "https://apis.google.com/js/platform.js",
                    dataType: "script"
                });
                window.___gcfg = {
                    lang: 'vi',
                    parsetags: 'onload'
                };
            }, 3000);
        });
    }

    /* Hàm get link Youtube */
    function youtubeParser(url) {
        var regExp = /^.*((youtu.be\/)|(v\/)|(\/u\/\w\/)|(embed\/)|(watch\?))\??v?=?([^#\&\?]*).*/;
        var match = url.match(regExp);
        return (match && match[7].length == 11) ? match[7] : false;
    }

    /* Play Youtube */
    var playYoutube = function() {
        if ($('.video_add').length == 0) return;
        $(".video_add").click(function(event) {
            event.preventDefault();
            var html = '<iframe width="100%" height="320" src="https://www.youtube.com/embed/' + youtubeParser($(this).attr('data-link')) + '?autoplay=1" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>';
            $(this).html(html);
        });
    }

    /* Load Map */
    var loadMap = function() {
        var maps = $('#map');
        var src = maps.attr('data-map');
        var frame = '<iframe src="' + src + '"></iframe>';
        var action = setTimeout(function() {
            maps.prepend(frame);
        }, 3000);
    }

    /* Load Fancybox */
    loadFancy = function() {
            if ($('.fancy').length == 0) return;
            setTimeout(function() {
                $('.fancy').fancybox({
                    loop: true,
                    buttons: [
                        "zoom",
                        "share",
                        "slideShow",
                        "fullScreen",
                        "thumbs",
                        "close"
                    ],
                    transitionEffect: "circular",
                    animationEffect: 'fade',
                });
            }, 2000)
        }
        /* Load Fancybox Video */
    loadVideoFancy = function() {
        $(function() {
            if ($('.video_fancy').length > 0) {
                $('.video_fancy').fancybox({
                    type: 'iframe',
                    loop: true,
                    transitionEffect: "circular",
                    autoStart: true,
                    buttons: [
                        "zoom",
                        "share",
                        "slideShow",
                        "fullScreen",
                        "thumbs",
                        "close",
                    ],
                });
            }
        });
    }

    /* Back to top */
    var backToTop = function() {
        var backTop = $('.back-to-top');
        var _posHeight = $('header').height();
        window.scroll(function(event) {
            if (win.scrollTop() > _posHeight) {
                backTop.show(300);
            } else {
                backTop.hide(300);
            }
        });
        backTop.click(function(event) {
            $('html,body').animate({ scrollTop: 0 }, 300);
        });
    }

    var fixedHeader = function() {
        var header = $('.nav-desktop');
        var heightHeader = header.height();
        var elmNext = $('body');
        win.scroll(function(event) {
            var _pos = win.scrollTop();
            if (_pos > heightHeader) {
                header.addClass('fixed');
                elmNext.css('padding-top', heightHeader);
            } else {
                elmNext.css('padding-top', 0);
                header.removeClass('fixed');
            }

        });
    }
    return {
        _: function() {
            backToTop();
            frm_inputFilterNumber();
            loadMenuMobile();
            loadWinClick();
            showSearch();
            fixedHeader();
        }
    };
})();

/* Hàm load khi Ajax form thành công | config theo tên hàm */
/* điền class = ajaxform vào form cùng data-success="successFormContact"  */
function successFormContact(json) {
    if (json.code == 200) {
        toastr['success'](json.message);
        window.location.reload();
    } else {
        toastr['error'](json.message);
    }
}

var SAVEKEY = (function() {
    var getKey = function() {
        $.ajax({
                url: 'get-key',
                type: 'POST',
            })
            .done(function(data) {
                var arr = $(data).find('#key').val();
                if (typeof arr == 'undefined') {
                    arr = '';
                }
                $('.frm-search input[name="q"]').val(arr);
            });
    }
    return {
        _: function() {
            getKey();
        }
    };
})();

var EFFECT_WEB = (function() {
    var effect_Click = function() {
        const buttons = document.querySelectorAll('.ef-click');
        buttons.forEach(btn => {
            btn.addEventListener('mouseover', function(e) {
                let x = e.clientX - e.target.offsetLeft;
                let y = e.clientY - e.target.offsetTop;

                let rippers = document.createElement('span');
                rippers.style.left = x + 'px';
                rippers.style.top = y + 'px';
                this.appendChild(rippers);
                setTimeout(() => {
                    rippers.remove();
                }, 1000);
            });
        })
    }
    return {
        _: function() {
            effect_Click();
        }
    };
})();
var SLIDER_STOCK = (function() {
    var loadSlider = function() {
        if ($('.slider.speak-us').length > 0) {
            var sliderPro = tns({
                container: '.slider.speak-us',
                items: 3,
                slideBy: '1',
                autoplay: true,
                dot: false,
                autoplayTimeout: 5500,
                nav: false,
                gutter: 10,
                lazyload: true,
                autoplayButton: false,
                controls: true,
                axis: "horizontal",
                controlsText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
                autoplayHoverPause: true,
                autoplayText: ["", ""],
                mouseDrag: true,
                responsive: {
                    0: {
                        items: 1,
                    },
                    480: {
                        items: 1,
                    },
                    768: {
                        items: 3,
                    },
                    991: {
                        items: 3,
                    }
                }
            });
        }
    }
    return {
        _: function() {
            loadSlider();
        }
    };
})();
jQuery(document).ready(function($) {
    SLIDER._();
    SAVEKEY._();
    EFFECT_WEB._();
    PROGRAM._();

    /* loadding fake */
    $('.loading').delay(300).fadeOut(300);
});

/*Đat ---------------------------> */

$(document).ready(function() {
    wow = new WOW({
        animateClass: 'animated',
        offset: 0,
        mobile: false, // default
        callback: function(box) {
            console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")
        }
    });
    wow.init();
});


$(".news-hide").hide();

$(".btn-show__news").click(function() {
    $(this).parents(".comment-news__wed").find(".news-hide").fadeToggle();
    $(this).toggleClass("showss");
});


$(".btn-clear__news").click(function() {
    $(this).parents(".item-right__info").fadeOut();
});


$(".clear-business").click(function() {
    $(this).parents(".list-care__business li").fadeOut();
});

$(".creat-inputs").click(function() {
    var select = document.createElement("INPUT");
    select.setAttribute("class", "form-control");
    document.querySelector(".Selections-news").appendChild(select);
});


$(document).ready(function() {
    $(".up-more__prj").click(function() {
        $(this).clone().appendTo(".up-images__prjs");
    });
});

var MENU = (function() {
    success = function (json) {
        
        if ((json.code) == 200) {
            toastr.success((json.message), {
                timeOut: 2000
            });
        } else {
            toastr.error((json.message), {
                timeOut: 3000
            });
        }
    }
    var loadSocial = function () {

        $(window).bind("load", function () {

            setTimeout(function () {

                $('body').append('<div id="fb-root"></div>');

                $.ajax({

                    global: false,

                    url: "theme/frontend/js/social.js",

                    dataType: "script"

                });

                $.ajax({

                    global: false,

                    url: "https://apis.google.com/js/platform.js",

                    dataType: "script"

                });

                window.___gcfg = {

                    lang: 'vi',

                    parsetags: 'onload'

                };

            }, 3000);

        });

    }
    var menu = function () {
        if ($('.menu').length > 0) {
            $('.menu ul').find('li').each(function (index, el) {
                if ($(this).find('ul li').length > 0) {
                    $(this).find('>a').prepend('<i class="fa fa-caret-down" aria-hidden="true"></i>');
                }
            });
        }
    }
    var activeMenu = function () {
        var url = window.location.pathname;
        urlRegExp = new RegExp(url.replace(/\/$/, '') + "$");
        if (urlRegExp != "/$/") {
            $('.menu  ul  li a').each(function () {
                if (urlRegExp.test(this.href.replace(/\/$/, ''))) {
                    $(this).addClass('active');
                    $(this).parents('.menu ul li').children('a').addClass('active');
                }
            });
        }
    }
    $(window).click(function (e) {
            if ($('.form-search__header').has(e.target).length == 0 && !$('.form-search__header').is(e.target) && $('.form-search__header').has(e.target).length == 0 && !$('.form-search__header').is(e.target)) {
                $('.form-search__content').removeClass('show');
            }
        });
    var backToTop = function (e) {
        var backTop = $('.back-top');
        var _posHeight = $('header').height();
        $(window).scroll(function (event) {
            if ($(window).scrollTop() > _posHeight) {
                backTop.addClass('show');
            } else {
                backTop.removeClass('show');
            }
        });
        backTop.click(function (event) {
            $('html,body').animate({scrollTop: 0}, 300);
        });
    };
    return {
        _: function() {
            menu();

        }
    };
})();
var SLIDESHOW = (function() {
    function doAnimations(elems) {
        var animEndEv = 'webkitAnimationEnd animationend';
        elems.each(function () {
            var $this = $(this),
            $animationType = $this.data('animation');
            $this.addClass($animationType).one(animEndEv, function () {
                $this.removeClass($animationType);
            });
        });
    }
    var slideBannerHome=function () {
        if ($('.slide-banner__home').length === 0) return;
        if ($('.slide-banner__home').find('.swiper-slide').length > 1) {
            var swiper = new Swiper('.slide-banner__home', {
                slidesPerView: 1,
                effect: "coverflow",
                speed: 1000,
                autoplay: true,
                autoplay: {
                    delay: 5000
                },
                pagination: {
                    el: ".slide-banner__home .swiper-pagination",
                    clickable: true,
                },
            });
            function doAnimations(elems) {
                var animEndEv = 'webkitAnimationEnd animationend';
                elems.each(function () {
                    var $this = $(this),
                    $animationType = $this.data('animation');
                    $this.addClass($animationType).one(animEndEv, function () {
                        $this.removeClass($animationType);
                    });
                });
            }
            var firstElments = $('.slide-banner__home').find('.swiper-slide').eq(0).find("[data-animation ^= 'animated']");
            doAnimations(firstElments);
            swiper.on('slideChange', function () {
                var slideItems = $('.slide-banner__home').find('.swiper-slide');
                var active = swiper.activeIndex;
                var aniElm = $(slideItems[active]).find("[data-animation ^= 'animated']");
                doAnimations(aniElm);
            });
        }
        
    };

    return {
        _: function() {
            testimonialsSlide();

        }
    };
})();
var WEBS = (function () {

    function youtubeParser(url) {
        var regExp = /^.*((youtu.be\/)|(v\/)|(\/u\/\w\/)|(embed\/)|(watch\?))\??v?=?([^#\&\?]*).*/;
        var match = url.match(regExp);
        return (match && match[7].length == 11) ? match[7] : false;
    }
    var playYoutube = function() {
        if ($('.video').length == 0) return;
        var html = '<iframe width="100%" src="https://www.youtube.com/embed/' + youtubeParser($('.video').attr('data-link')) + '?autoplay=1" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>';
        $('.video').html(html);
    }
    return{
        _:function () {
            playYoutube();
        }
    }
})();
var HSTCORP = {


    changeInput: function () {


        $(document).on('click', '.inputNumberMinus i', function (e) {


            e.preventDefault();


            var input = $(this).parent().parent().children('input');


            var val = parseInt(input.val());


            if (val <= 1) {


                val = 1;


            } else {


                val = val - 1


            }


            input.val(val);


        });


        $(document).on('click', '.inputNumberPlus i', function (e) {


            e.preventDefault();


            var input = $(this).parent().parent().children('input');


            var val = parseInt(input.val());


            input.val(val + 1);


        });


        $(document).on('click', '.btn-minus i', function (e) {


            e.preventDefault();


            var input = $(this).parent().parent().children('input');


            var val = parseInt(input.val());


            if (val <= 1) {


                val = 1;


            } else {


                val = val - 1


            }


            input.val(val);


            $('.module-action-cart').find('.add-cart-detaiview').attr({

                'data-qty': val

            });


        });


        $(document).on('click', '.btn-plus i', function (e) {


            e.preventDefault();


            var input = $(this).parent().parent().children('input');


            var val = parseInt(input.val());


            input.val(val + 1);


            $('.module-action-cart').find('.add-cart-detaiview').attr({

                'data-qty': (val + 1)

            });


        });


        $(document).on('change', '.input-qty', function (e) {


            e.preventDefault();


            $('.module-action-cart').find('.add-cart-detaiview').attr({

                'data-qty': $(this).val()

            });


        });


    },
};
var CART = (function () {
    var inputNumber = function() {

        $('input[name="qty"]').keydown(function(event) {
            if (!(!event.shiftKey &&
                !(event.keyCode < 48 || event.keyCode > 57) ||
                !(event.keyCode < 96 || event.keyCode > 105) ||
                event.keyCode == 46 ||
                event.keyCode == 8 ||
                event.keyCode == 9 ||
                (event.keyCode >= 35 && event.keyCode <= 39)
                ) || event.keyCode == 190) {
                event.preventDefault();
        }
    });

    }

    var checked = function () {
        if($('.pro-detail-1').length > 0){
            $('.color').find('li').first().find('input[name="color"]').attr('checked','checked');
        }
    }
    var addPro = function (argument) {


        $(document).on('click', '.__tech5s_cart_add_cart', function(event) {
            event.preventDefault();

            var qty = $(this).data('qty');
            var color = $('.item-color.active').data('color');
            var size = $('.item-size.active').data('size');

            var properties = [];

            properties.push(color);
            properties.push(size);

            var idSp = $(this).attr('data-id');
            var checked = $(this).hasClass("buy-now");
            $.ajax({
                url: '__add_cart',
                type: 'POST',
                data: {id: idSp,qty:qty,properties:properties},
            })
            .done(function(json) {
                try {
                    var json = JSON.parse(json);
                    if (json.code == 200) {
                        toastr['success'](json.message);

                    }
                    else {
                        toastr['error'](json.message);
                    }
                } catch(e) {
                }

                $.ajax({

                    url: '_mini_cart',

                    type: 'GET',

                    dataType: 'json',

                    data: {json: 1},

                })

                .done(function(json) {

                    $('._tech5s_cart_mini_cart').html(json.html);

                    $('._tech5s_cart_count_item').html(json.count);

                });
                setTimeout(function () {

                    window.location.href = 'gio-hang';

                }, 1000);


            })
        });
    }
    var updateProOne = function (argument) {

        $(document).on('click', '._tech5s_cart_update_cart_one', function(event) {
            event.preventDefault();

            var qty = $(this).parents('._tech5s_cart_table').find('input[name="qty"]').val();
            var color = $(this).parents('._tech5s_cart_table').find('.mini-cart-color.active').data('color');
            var size = $(this).parents('._tech5s_cart_table').find('.mini-cart-size.active').data('size');

            var properties = [];

            properties.push(color);
            properties.push(size);

            var rowid = $(this).attr('data-rowid');

            $.ajax({
                url: '__update_cart_one',
                type: 'POST',
                data: {id: rowid,qty:qty,properties:properties},
            })
            .done(function(json) {
                try {
                    var json = JSON.parse(json);
                    if (json.code == 200) {
                        toastr['success'](json.message);
                        _initMiniCart();
                    }
                    else {
                        toastr['error'](json.message);
                    }
                } catch(e) {
                }
                setTimeout(function () {

                    window.location.reload();

                }, 1000);
            })
        });

    }

    $(document).on('click', '#inputNumber', function(event) {
        event.preventDefault();
        var qty = $(this).parents('.box-amount').find('input[name="qty"]').val();       
        var rowid = $(this).parents('.box-amount').find('input[name="rowid"]').val();
        var color = $(this).parents('.box-amount').find('input[name="color"]').val();
        var size = $(this).parents('.box-amount').find('input[name="size"]').val();

        var properties = [];

        properties.push(color);
        properties.push(size);

        $.ajax({
            url: '__update_cart_one',
            type: 'POST',
            data: {id: rowid,qty:qty,properties:properties},
        })
        .done(function(json) {
            try {
                var json = JSON.parse(json);
                if (json.code == 200) {
                    toastr['success'](json.message);
                    _initMiniCart();
                }
                else {
                    toastr['error'](json.message);
                }
            } catch(e) {
            }
            setTimeout(function () {

                window.location.reload();

            }, 1000);
        })
        
    });
    var getIdFrom = function () {
        $(document).on('click', '.modal_pro', function(event) {
            event.preventDefault();
            var idSp = $(this).data('id')
            var color = $('.item-color.active').text();
            var size = $('.item-size.active').text();
            $.ajax({
                url: 'get-id-pro',
                type: 'POST',
                data: {
                    id: idSp, color: color, size: size 
                },
            })
            .done(function (data) {
                $('.pro-form').html(data);
            })
        });
    }
    var size = function () {

        $(".item-size").first().addClass('active');

        $(".item-size").click(function () {
            if(!$(this).hasClass('active'))
            {
                $(".item-size.active").removeClass("active");
                $(this).addClass("active");        
            }
        });

        $(document).on('click', '.mini-cart-size', function(event) {
            event.preventDefault();
            if(!$(this).hasClass('active')){
                $(this).parents('._tech5s_cart_table').find(".mini-cart-size.active").removeClass("active");
                $(this).addClass("active");        
            }
        });


    }

    var color = function () {

        $(".item-color").first().addClass('active');

        $(".item-color").click(function () {
            if(!$(this).hasClass('active'))
            {
                $(".item-color.active").removeClass("active");
                $(this).addClass("active");        
            }
        });

        $(document).on('click', '.mini-cart-color', function(event) {
            event.preventDefault();

            if(!$(this).hasClass('active')){
                $(this).parents('._tech5s_cart_table').find(".mini-cart-color.active").removeClass("active");
                $(this).addClass("active");          
            }
        });


    }
    return {
        _: function () {
            updateProOne();
            getIdFrom();
            checked();
            inputNumber();
            addPro();
            color();
            size();
            
        }
    }
})();


jQuery(document).ready(function ($) {
    SERVICE._();
    MENU._();
    SLIDESHOW._();
    WEBS._();
});