<html>

<head>
  <title></title>
  <meta name="viewport" content="width=device-width" initial-scale=1.0>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <link rel="stylesheet" href="theme/frontend/css/bootstrap.min.css">
  <link rel="stylesheet" href="theme/frontend/css/font-awesome.css">
  <link rel="stylesheet" href="theme/frontend/css/jquery.fancybox.css">
  <link rel="stylesheet" href="theme/frontend/css/toastr.min.css">
  <link rel="stylesheet" href="theme/frontend/css/swiper.min.css">
  <link rel="stylesheet" href="theme/frontend/css/reset.css">
  <link rel="stylesheet" href="theme/frontend/css/style.css">
  <link rel="stylesheet" href="theme/frontend/css/mobile.css">

</head>

<body> 
  <?php 
    require_once 'service/getData.php';
  ?>
  <div class="container">
    <div class="row">
      <form action="" class="col-6"></form>
    </div>
  </div>
  


</body>
<script src="theme/frontend/js/jquery-3.4.1.min.js" defer></script>
<script src="theme/frontend/js/bootstrap.min.js" defer></script>
<script src="theme/frontend/js/wow.min.js" defer></script>
<script src="theme/frontend/js/valiForm.min.js" defer></script>
<script src="theme/frontend/js/toastr.min.js" defer></script>
<script src="theme/frontend/js/swiper.min.js" defer></script>
<script src="theme/frontend/js/jquery.fancybox.min.js" defer></script>
<script src="theme/frontend/js/script.js" defer></script>


</html>

