<html>

<head>
	<title></title>
	<meta name="viewport" content="width=device-width" initial-scale=1.0>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
	<link rel="stylesheet" href="theme/frontend/css/font-awesome.css">
	<link rel="stylesheet" href="theme/frontend/css/jquery.fancybox.css">
	<link rel="stylesheet" href="theme/frontend/css/toastr.min.css">
	<link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css"/>
	<link rel="stylesheet" href="theme/frontend/css/reset.css">
	<link rel="stylesheet" href="theme/frontend/css/style.css">
	<link rel="stylesheet" href="theme/frontend/css/mobile.css">

</head>

<body> 

	<div class="product-main">
		<div class="container">
			<h1 class="title_h">Bồn cầu 1 khối</h1>
			<div class="row">
				<div class="col-7">
					<div thumbsSlider="" class="swiper detail_pro_1">
						<div class="swiper-wrapper">
							<?php for ($i = 1; $i <= 5; $i++) { ?>
								<div class="swiper-slide">
									<div class="box-img">
										<img src="theme/frontend/images/chauruamat.png" />
									</div>
								</div>
							<?php }?>		
						</div>
					</div>
					<div class="swiper detail_pro_2">
						<div class="swiper-wrapper">
							<?php for ($i = 1; $i <= 5; $i++) { ?>
								<div class="swiper-slide">
									<div class="box-img-icon">
										<img src="theme/frontend/images/chauruamat.png" />
									</div>
								</div>
							<?php }?>
						</div>
					</div>
				</div>
				<div class="col-5 d-flex align-items-end">
					<div class="product-detail w-100">
						<ul class="box-detail">
							<li>Mã sản phẩm: <span>8823UF</span> | Đánh giá: </li>
							<li>Danh mục: <span>Bồn cầu</span></li>
							<li>Bảo hành: <span>Phần xứ bảo hành 10 năm</span></li>
							<li>Tình trạng: <span>Còn hàng</span></li>
						</ul>
						<div class="box-contact">
							<a href="" class="smooth contact" title="">Liên hệ</a>
							<a href="" class="smooth regis-cart" title="">Đăng ký bán hàng</a>
						</div>

						<div class="box-share">
							<p class="t_service">Dịch vụ và khuyến mãi</p>
							<p class="te_service">Dịch vụ và khuyến mãi</p>
							<div class="share">
								<p class="t_share">Chia sẻ:</p>
								<ul>
									<li>
										<a href="" title="" class="smooth">
											<i class="fa fa-facebook"></i>
										</a>
									</li>
									<li>
										<a href="" title="" class="smooth">
											<i class="fa fa"></i>
										</a>
									</li>
									<li><a href="" title="" class="smooth"></a></li>
									<li><a href="" title="" class="smooth"></a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>				
			</div>
		</div>
		<div class="truck-advise mt-5 mb-5">
			<div class="container ">
				<div class="row">
					<?php for ($i = 1; $i <= 3; $i++) { ?>
						<div class="col-4">
							<div class="box-img">
								<img src="theme/frontend/images/baomat.png">
							</div>
							<p class="title text-center mt-2">100% hàng đặt tiêu chuẩn chất lượng cao</p>
						</div>
					<?php }?>
				</div>
			</div>	
		</div>
	</div>
	<div class="container">
		<div class="row">
			<div class="col-6">
				<div class="s-content"></div>
			</div>
			<div class="col-6">
				<p class="title_skill mb-3">Thông số lỹ thuật: </p>
				<div class="box-skill">
					<ul>
						<li><span>Loại: </span> <span>Bồn cầu</span></li>
						<li><span>Loại: </span> <span>Bồn cầu</span></li>
						<li><span>Loại: </span> <span>Bồn cầu</span></li>
						<li><span>Loại: </span> <span>Bồn cầu</span></li>
						<li><span>Loại: </span> <span>Bồn cầu</span></li>

					</ul>
				</div>
				<div class="box-contact-skill">
					<a href="" class="smooth contact" title="">Liên hệ</a>
					<a href="" class="smooth regis-cart" title="">Đăng ký bán hàng</a>
				</div>
			</div>
		</div>
	</div>
	<div class="box-products-new mb-5">
		<div class="container">
			<div class="box-title">
				<h2 class="title">Sản phẩm mới</h2>
				<a href="" title="" class="smooth views-more">Xem thêm</a>
			</div>
			<div class="swiper product-slide-new mt-5">
				<div class="swiper-wrapper">
					<?php for ($i = 1; $i <= 6; $i++) { ?>
						<div class="swiper-slide">
							<div class="box-card-pro">
								<a href="" title="" class="smooth box-img">
									<img src="theme/frontend/images/chauruamat.png" >
								</a>
								<h3 class="pro-name text-center mt-4">Chậu rửa đặt bàn TK58</h3>
							</div>
						</div>
					<?php }?>
				</div>
				<div class="swiper-button-next"></div>
				<div class="swiper-button-prev"></div>
				<!-- 					<div class="swiper-pagination"></div> -->
			</div>
		</div>
	</div>
</div>




</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
<script type="text/javascript" src="theme/frontend/js/jquery-3.4.1.min.js" defer=""></script>
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
<script src="theme/frontend/js/test.js" defer></script>


</html>

